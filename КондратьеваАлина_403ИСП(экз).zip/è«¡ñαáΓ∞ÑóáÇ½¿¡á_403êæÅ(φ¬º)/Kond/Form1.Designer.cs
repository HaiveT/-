﻿namespace Kond
{
    partial class Участники
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Участники));
            System.Windows.Forms.Label название_клубаLabel;
            System.Windows.Forms.Label кличка_собакиLabel;
            System.Windows.Forms.Label порода_собакиLabel;
            System.Windows.Forms.Label возрастLabel;
            System.Windows.Forms.Label сведения_о_родословнойLabel;
            System.Windows.Forms.Label дата_последней_прививкиLabel;
            System.Windows.Forms.Label хозяинLabel;
            System.Windows.Forms.Label рингLabel;
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.kONDRATEVADataSet = new Kond.KONDRATEVADataSet();
            this.собаки_УчастникиBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.собаки_УчастникиTableAdapter = new Kond.KONDRATEVADataSetTableAdapters.Собаки_УчастникиTableAdapter();
            this.tableAdapterManager = new Kond.KONDRATEVADataSetTableAdapters.TableAdapterManager();
            this.собаки_УчастникиBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.собаки_УчастникиBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.название_клубаTextBox = new System.Windows.Forms.TextBox();
            this.кличка_собакиTextBox = new System.Windows.Forms.TextBox();
            this.порода_собакиTextBox = new System.Windows.Forms.TextBox();
            this.возрастTextBox = new System.Windows.Forms.TextBox();
            this.сведения_о_родословнойTextBox = new System.Windows.Forms.TextBox();
            this.дата_последней_прививкиDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.рингTextBox = new System.Windows.Forms.TextBox();
            this.хозяин_УчастникаBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.хозяин_УчастникаTableAdapter = new Kond.KONDRATEVADataSetTableAdapters.Хозяин_УчастникаTableAdapter();
            this.фамилияTextBox = new System.Windows.Forms.TextBox();
            название_клубаLabel = new System.Windows.Forms.Label();
            кличка_собакиLabel = new System.Windows.Forms.Label();
            порода_собакиLabel = new System.Windows.Forms.Label();
            возрастLabel = new System.Windows.Forms.Label();
            сведения_о_родословнойLabel = new System.Windows.Forms.Label();
            дата_последней_прививкиLabel = new System.Windows.Forms.Label();
            хозяинLabel = new System.Windows.Forms.Label();
            рингLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.kONDRATEVADataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.собаки_УчастникиBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.собаки_УчастникиBindingNavigator)).BeginInit();
            this.собаки_УчастникиBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.хозяин_УчастникаBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Bisque;
            this.button1.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.ForeColor = System.Drawing.Color.SaddleBrown;
            this.button1.Location = new System.Drawing.Point(12, 49);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(146, 68);
            this.button1.TabIndex = 0;
            this.button1.Text = "Добавление участника";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Bisque;
            this.button2.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.ForeColor = System.Drawing.Color.SaddleBrown;
            this.button2.Location = new System.Drawing.Point(164, 49);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(146, 68);
            this.button2.TabIndex = 1;
            this.button2.Text = "Отстранение участника";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Bisque;
            this.button3.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button3.ForeColor = System.Drawing.Color.SaddleBrown;
            this.button3.Location = new System.Drawing.Point(654, 60);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(118, 57);
            this.button3.TabIndex = 2;
            this.button3.Text = "Эксперты";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Bisque;
            this.button4.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button4.ForeColor = System.Drawing.Color.SaddleBrown;
            this.button4.Location = new System.Drawing.Point(604, 443);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(168, 100);
            this.button4.TabIndex = 3;
            this.button4.Text = "Справка о призовом месте";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Bisque;
            this.button5.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button5.ForeColor = System.Drawing.Color.SaddleBrown;
            this.button5.Location = new System.Drawing.Point(604, 549);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(168, 100);
            this.button5.TabIndex = 4;
            this.button5.Text = "Отчет о результатах выступления";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Linen;
            this.label1.Font = new System.Drawing.Font("Candara", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.label1.Location = new System.Drawing.Point(341, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(276, 39);
            this.label1.TabIndex = 5;
            this.label1.Text = "ВЫСТАВКА СОБАК";
            // 
            // kONDRATEVADataSet
            // 
            this.kONDRATEVADataSet.DataSetName = "KONDRATEVADataSet";
            this.kONDRATEVADataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // собаки_УчастникиBindingSource
            // 
            this.собаки_УчастникиBindingSource.DataMember = "Собаки_Участники";
            this.собаки_УчастникиBindingSource.DataSource = this.kONDRATEVADataSet;
            // 
            // собаки_УчастникиTableAdapter
            // 
            this.собаки_УчастникиTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.UpdateOrder = Kond.KONDRATEVADataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.КлубTableAdapter = null;
            this.tableAdapterManager.Сведения_о_РодословнойTableAdapter = null;
            this.tableAdapterManager.Сведения_об_ЭкспертеTableAdapter = null;
            this.tableAdapterManager.Собаки_УчастникиTableAdapter = this.собаки_УчастникиTableAdapter;
            this.tableAdapterManager.Хозяин_УчастникаTableAdapter = this.хозяин_УчастникаTableAdapter;
            // 
            // собаки_УчастникиBindingNavigator
            // 
            this.собаки_УчастникиBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.собаки_УчастникиBindingNavigator.BindingSource = this.собаки_УчастникиBindingSource;
            this.собаки_УчастникиBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.собаки_УчастникиBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.собаки_УчастникиBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.собаки_УчастникиBindingNavigatorSaveItem});
            this.собаки_УчастникиBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.собаки_УчастникиBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.собаки_УчастникиBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.собаки_УчастникиBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.собаки_УчастникиBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.собаки_УчастникиBindingNavigator.Name = "собаки_УчастникиBindingNavigator";
            this.собаки_УчастникиBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.собаки_УчастникиBindingNavigator.Size = new System.Drawing.Size(792, 25);
            this.собаки_УчастникиBindingNavigator.TabIndex = 6;
            this.собаки_УчастникиBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // собаки_УчастникиBindingNavigatorSaveItem
            // 
            this.собаки_УчастникиBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.собаки_УчастникиBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("собаки_УчастникиBindingNavigatorSaveItem.Image")));
            this.собаки_УчастникиBindingNavigatorSaveItem.Name = "собаки_УчастникиBindingNavigatorSaveItem";
            this.собаки_УчастникиBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.собаки_УчастникиBindingNavigatorSaveItem.Text = "Сохранить данные";
            this.собаки_УчастникиBindingNavigatorSaveItem.Click += new System.EventHandler(this.собаки_УчастникиBindingNavigatorSaveItem_Click);
            // 
            // название_клубаLabel
            // 
            название_клубаLabel.AutoSize = true;
            название_клубаLabel.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            название_клубаLabel.Location = new System.Drawing.Point(12, 140);
            название_клубаLabel.Name = "название_клубаLabel";
            название_клубаLabel.Size = new System.Drawing.Size(163, 26);
            название_клубаLabel.TabIndex = 7;
            название_клубаLabel.Text = "Название клуба:";
            // 
            // название_клубаTextBox
            // 
            this.название_клубаTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.собаки_УчастникиBindingSource, "Название клуба", true));
            this.название_клубаTextBox.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.название_клубаTextBox.Location = new System.Drawing.Point(275, 140);
            this.название_клубаTextBox.Name = "название_клубаTextBox";
            this.название_клубаTextBox.Size = new System.Drawing.Size(323, 33);
            this.название_клубаTextBox.TabIndex = 8;
            // 
            // кличка_собакиLabel
            // 
            кличка_собакиLabel.AutoSize = true;
            кличка_собакиLabel.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            кличка_собакиLabel.Location = new System.Drawing.Point(12, 179);
            кличка_собакиLabel.Name = "кличка_собакиLabel";
            кличка_собакиLabel.Size = new System.Drawing.Size(153, 26);
            кличка_собакиLabel.TabIndex = 9;
            кличка_собакиLabel.Text = "Кличка собаки:";
            кличка_собакиLabel.Click += new System.EventHandler(this.кличка_собакиLabel_Click);
            // 
            // кличка_собакиTextBox
            // 
            this.кличка_собакиTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.собаки_УчастникиBindingSource, "Кличка собаки", true));
            this.кличка_собакиTextBox.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.кличка_собакиTextBox.Location = new System.Drawing.Point(275, 179);
            this.кличка_собакиTextBox.Name = "кличка_собакиTextBox";
            this.кличка_собакиTextBox.Size = new System.Drawing.Size(323, 33);
            this.кличка_собакиTextBox.TabIndex = 10;
            // 
            // порода_собакиLabel
            // 
            порода_собакиLabel.AutoSize = true;
            порода_собакиLabel.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            порода_собакиLabel.Location = new System.Drawing.Point(12, 218);
            порода_собакиLabel.Name = "порода_собакиLabel";
            порода_собакиLabel.Size = new System.Drawing.Size(158, 26);
            порода_собакиLabel.TabIndex = 11;
            порода_собакиLabel.Text = "Порода собаки:";
            // 
            // порода_собакиTextBox
            // 
            this.порода_собакиTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.собаки_УчастникиBindingSource, "Порода собаки", true));
            this.порода_собакиTextBox.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.порода_собакиTextBox.Location = new System.Drawing.Point(275, 218);
            this.порода_собакиTextBox.Name = "порода_собакиTextBox";
            this.порода_собакиTextBox.Size = new System.Drawing.Size(323, 33);
            this.порода_собакиTextBox.TabIndex = 12;
            // 
            // возрастLabel
            // 
            возрастLabel.AutoSize = true;
            возрастLabel.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            возрастLabel.Location = new System.Drawing.Point(12, 257);
            возрастLabel.Name = "возрастLabel";
            возрастLabel.Size = new System.Drawing.Size(92, 26);
            возрастLabel.TabIndex = 13;
            возрастLabel.Text = "Возраст:";
            // 
            // возрастTextBox
            // 
            this.возрастTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.собаки_УчастникиBindingSource, "Возраст", true));
            this.возрастTextBox.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.возрастTextBox.Location = new System.Drawing.Point(275, 257);
            this.возрастTextBox.Name = "возрастTextBox";
            this.возрастTextBox.Size = new System.Drawing.Size(323, 33);
            this.возрастTextBox.TabIndex = 14;
            // 
            // сведения_о_родословнойLabel
            // 
            сведения_о_родословнойLabel.AutoSize = true;
            сведения_о_родословнойLabel.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            сведения_о_родословнойLabel.Location = new System.Drawing.Point(12, 296);
            сведения_о_родословнойLabel.Name = "сведения_о_родословнойLabel";
            сведения_о_родословнойLabel.Size = new System.Drawing.Size(253, 26);
            сведения_о_родословнойLabel.TabIndex = 15;
            сведения_о_родословнойLabel.Text = "Сведения о родословной:";
            // 
            // сведения_о_родословнойTextBox
            // 
            this.сведения_о_родословнойTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.собаки_УчастникиBindingSource, "Сведения о родословной", true));
            this.сведения_о_родословнойTextBox.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.сведения_о_родословнойTextBox.Location = new System.Drawing.Point(275, 296);
            this.сведения_о_родословнойTextBox.Name = "сведения_о_родословнойTextBox";
            this.сведения_о_родословнойTextBox.Size = new System.Drawing.Size(323, 33);
            this.сведения_о_родословнойTextBox.TabIndex = 16;
            // 
            // дата_последней_прививкиLabel
            // 
            дата_последней_прививкиLabel.AutoSize = true;
            дата_последней_прививкиLabel.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            дата_последней_прививкиLabel.Location = new System.Drawing.Point(12, 335);
            дата_последней_прививкиLabel.Name = "дата_последней_прививкиLabel";
            дата_последней_прививкиLabel.Size = new System.Drawing.Size(259, 26);
            дата_последней_прививкиLabel.TabIndex = 17;
            дата_последней_прививкиLabel.Text = "Дата последней прививки:";
            // 
            // дата_последней_прививкиDateTimePicker
            // 
            this.дата_последней_прививкиDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.собаки_УчастникиBindingSource, "Дата последней прививки", true));
            this.дата_последней_прививкиDateTimePicker.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.дата_последней_прививкиDateTimePicker.Location = new System.Drawing.Point(275, 335);
            this.дата_последней_прививкиDateTimePicker.Name = "дата_последней_прививкиDateTimePicker";
            this.дата_последней_прививкиDateTimePicker.Size = new System.Drawing.Size(323, 33);
            this.дата_последней_прививкиDateTimePicker.TabIndex = 18;
            // 
            // хозяинLabel
            // 
            хозяинLabel.AutoSize = true;
            хозяинLabel.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            хозяинLabel.Location = new System.Drawing.Point(12, 374);
            хозяинLabel.Name = "хозяинLabel";
            хозяинLabel.Size = new System.Drawing.Size(83, 26);
            хозяинLabel.TabIndex = 19;
            хозяинLabel.Text = "Хозяин:";
            // 
            // рингLabel
            // 
            рингLabel.AutoSize = true;
            рингLabel.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            рингLabel.Location = new System.Drawing.Point(12, 413);
            рингLabel.Name = "рингLabel";
            рингLabel.Size = new System.Drawing.Size(60, 26);
            рингLabel.TabIndex = 21;
            рингLabel.Text = "Ринг:";
            // 
            // рингTextBox
            // 
            this.рингTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.собаки_УчастникиBindingSource, "Ринг", true));
            this.рингTextBox.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.рингTextBox.Location = new System.Drawing.Point(275, 413);
            this.рингTextBox.Name = "рингTextBox";
            this.рингTextBox.Size = new System.Drawing.Size(323, 33);
            this.рингTextBox.TabIndex = 22;
            // 
            // хозяин_УчастникаBindingSource
            // 
            this.хозяин_УчастникаBindingSource.DataMember = "Хозяин_Участника";
            this.хозяин_УчастникаBindingSource.DataSource = this.kONDRATEVADataSet;
            // 
            // хозяин_УчастникаTableAdapter
            // 
            this.хозяин_УчастникаTableAdapter.ClearBeforeFill = true;
            // 
            // фамилияTextBox
            // 
            this.фамилияTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.хозяин_УчастникаBindingSource, "Фамилия", true));
            this.фамилияTextBox.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.фамилияTextBox.Location = new System.Drawing.Point(275, 374);
            this.фамилияTextBox.Name = "фамилияTextBox";
            this.фамилияTextBox.Size = new System.Drawing.Size(323, 33);
            this.фамилияTextBox.TabIndex = 23;
            // 
            // Участники
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Linen;
            this.ClientSize = new System.Drawing.Size(792, 669);
            this.Controls.Add(this.фамилияTextBox);
            this.Controls.Add(рингLabel);
            this.Controls.Add(this.рингTextBox);
            this.Controls.Add(хозяинLabel);
            this.Controls.Add(дата_последней_прививкиLabel);
            this.Controls.Add(this.дата_последней_прививкиDateTimePicker);
            this.Controls.Add(сведения_о_родословнойLabel);
            this.Controls.Add(this.сведения_о_родословнойTextBox);
            this.Controls.Add(возрастLabel);
            this.Controls.Add(this.возрастTextBox);
            this.Controls.Add(порода_собакиLabel);
            this.Controls.Add(this.порода_собакиTextBox);
            this.Controls.Add(кличка_собакиLabel);
            this.Controls.Add(this.кличка_собакиTextBox);
            this.Controls.Add(название_клубаLabel);
            this.Controls.Add(this.название_клубаTextBox);
            this.Controls.Add(this.собаки_УчастникиBindingNavigator);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Участники";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Участники";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.kONDRATEVADataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.собаки_УчастникиBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.собаки_УчастникиBindingNavigator)).EndInit();
            this.собаки_УчастникиBindingNavigator.ResumeLayout(false);
            this.собаки_УчастникиBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.хозяин_УчастникаBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label1;
        private KONDRATEVADataSet kONDRATEVADataSet;
        private System.Windows.Forms.BindingSource собаки_УчастникиBindingSource;
        private KONDRATEVADataSetTableAdapters.Собаки_УчастникиTableAdapter собаки_УчастникиTableAdapter;
        private KONDRATEVADataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator собаки_УчастникиBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton собаки_УчастникиBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox название_клубаTextBox;
        private System.Windows.Forms.TextBox кличка_собакиTextBox;
        private System.Windows.Forms.TextBox порода_собакиTextBox;
        private System.Windows.Forms.TextBox возрастTextBox;
        private System.Windows.Forms.TextBox сведения_о_родословнойTextBox;
        private System.Windows.Forms.DateTimePicker дата_последней_прививкиDateTimePicker;
        private System.Windows.Forms.TextBox рингTextBox;
        private KONDRATEVADataSetTableAdapters.Хозяин_УчастникаTableAdapter хозяин_УчастникаTableAdapter;
        private System.Windows.Forms.BindingSource хозяин_УчастникаBindingSource;
        private System.Windows.Forms.TextBox фамилияTextBox;
    }
}

