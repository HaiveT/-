﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kond
{
    public partial class Участники : Form
    {
        public Участники()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "kONDRATEVADataSet.Хозяин_Участника". При необходимости она может быть перемещена или удалена.
            this.хозяин_УчастникаTableAdapter.Fill(this.kONDRATEVADataSet.Хозяин_Участника);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "kONDRATEVADataSet.Собаки_Участники". При необходимости она может быть перемещена или удалена.
            this.собаки_УчастникиTableAdapter.Fill(this.kONDRATEVADataSet.Собаки_Участники);

        }

        private void собаки_УчастникиBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.собаки_УчастникиBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.kONDRATEVADataSet);

        }

        private void кличка_собакиLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
