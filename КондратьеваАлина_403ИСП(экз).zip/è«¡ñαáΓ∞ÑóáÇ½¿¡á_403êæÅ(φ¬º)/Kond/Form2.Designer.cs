﻿namespace Kond
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            System.Windows.Forms.Label фамилияLabel;
            System.Windows.Forms.Label имяLabel;
            System.Windows.Forms.Label номер_рингаLabel;
            System.Windows.Forms.Label название_клубаLabel;
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.kONDRATEVADataSet = new Kond.KONDRATEVADataSet();
            this.сведения_об_ЭкспертеBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.сведения_об_ЭкспертеTableAdapter = new Kond.KONDRATEVADataSetTableAdapters.Сведения_об_ЭкспертеTableAdapter();
            this.tableAdapterManager = new Kond.KONDRATEVADataSetTableAdapters.TableAdapterManager();
            this.сведения_об_ЭкспертеBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.сведения_об_ЭкспертеBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.фамилияTextBox = new System.Windows.Forms.TextBox();
            this.имяTextBox = new System.Windows.Forms.TextBox();
            this.номер_рингаTextBox = new System.Windows.Forms.TextBox();
            this.название_клубаTextBox = new System.Windows.Forms.TextBox();
            фамилияLabel = new System.Windows.Forms.Label();
            имяLabel = new System.Windows.Forms.Label();
            номер_рингаLabel = new System.Windows.Forms.Label();
            название_клубаLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.kONDRATEVADataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.сведения_об_ЭкспертеBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.сведения_об_ЭкспертеBindingNavigator)).BeginInit();
            this.сведения_об_ЭкспертеBindingNavigator.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Bisque;
            this.button1.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.ForeColor = System.Drawing.Color.SaddleBrown;
            this.button1.Location = new System.Drawing.Point(13, 51);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(130, 106);
            this.button1.TabIndex = 0;
            this.button1.Text = "Добавить эксперта";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Candara", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.label1.Location = new System.Drawing.Point(346, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(276, 39);
            this.label1.TabIndex = 1;
            this.label1.Text = "ВЫСТАВКА СОБАК";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Bisque;
            this.button2.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.ForeColor = System.Drawing.Color.SaddleBrown;
            this.button2.Location = new System.Drawing.Point(149, 51);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(130, 106);
            this.button2.TabIndex = 2;
            this.button2.Text = "Снять эксперта с судейства";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Bisque;
            this.button3.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button3.ForeColor = System.Drawing.Color.SaddleBrown;
            this.button3.Location = new System.Drawing.Point(645, 597);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(135, 60);
            this.button3.TabIndex = 3;
            this.button3.Text = "Назад";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // kONDRATEVADataSet
            // 
            this.kONDRATEVADataSet.DataSetName = "KONDRATEVADataSet";
            this.kONDRATEVADataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // сведения_об_ЭкспертеBindingSource
            // 
            this.сведения_об_ЭкспертеBindingSource.DataMember = "Сведения_об_Эксперте";
            this.сведения_об_ЭкспертеBindingSource.DataSource = this.kONDRATEVADataSet;
            // 
            // сведения_об_ЭкспертеTableAdapter
            // 
            this.сведения_об_ЭкспертеTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.UpdateOrder = Kond.KONDRATEVADataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.КлубTableAdapter = null;
            this.tableAdapterManager.Сведения_о_РодословнойTableAdapter = null;
            this.tableAdapterManager.Сведения_об_ЭкспертеTableAdapter = this.сведения_об_ЭкспертеTableAdapter;
            this.tableAdapterManager.Собаки_УчастникиTableAdapter = null;
            this.tableAdapterManager.Хозяин_УчастникаTableAdapter = null;
            // 
            // сведения_об_ЭкспертеBindingNavigator
            // 
            this.сведения_об_ЭкспертеBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.сведения_об_ЭкспертеBindingNavigator.BindingSource = this.сведения_об_ЭкспертеBindingSource;
            this.сведения_об_ЭкспертеBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.сведения_об_ЭкспертеBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.сведения_об_ЭкспертеBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.сведения_об_ЭкспертеBindingNavigatorSaveItem});
            this.сведения_об_ЭкспертеBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.сведения_об_ЭкспертеBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.сведения_об_ЭкспертеBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.сведения_об_ЭкспертеBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.сведения_об_ЭкспертеBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.сведения_об_ЭкспертеBindingNavigator.Name = "сведения_об_ЭкспертеBindingNavigator";
            this.сведения_об_ЭкспертеBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.сведения_об_ЭкспертеBindingNavigator.Size = new System.Drawing.Size(792, 25);
            this.сведения_об_ЭкспертеBindingNavigator.TabIndex = 4;
            this.сведения_об_ЭкспертеBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // сведения_об_ЭкспертеBindingNavigatorSaveItem
            // 
            this.сведения_об_ЭкспертеBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.сведения_об_ЭкспертеBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("сведения_об_ЭкспертеBindingNavigatorSaveItem.Image")));
            this.сведения_об_ЭкспертеBindingNavigatorSaveItem.Name = "сведения_об_ЭкспертеBindingNavigatorSaveItem";
            this.сведения_об_ЭкспертеBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.сведения_об_ЭкспертеBindingNavigatorSaveItem.Text = "Сохранить данные";
            this.сведения_об_ЭкспертеBindingNavigatorSaveItem.Click += new System.EventHandler(this.сведения_об_ЭкспертеBindingNavigatorSaveItem_Click);
            // 
            // фамилияLabel
            // 
            фамилияLabel.AutoSize = true;
            фамилияLabel.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            фамилияLabel.Location = new System.Drawing.Point(8, 179);
            фамилияLabel.Name = "фамилияLabel";
            фамилияLabel.Size = new System.Drawing.Size(100, 26);
            фамилияLabel.TabIndex = 5;
            фамилияLabel.Text = "Фамилия:";
            // 
            // фамилияTextBox
            // 
            this.фамилияTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.сведения_об_ЭкспертеBindingSource, "Фамилия", true));
            this.фамилияTextBox.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.фамилияTextBox.Location = new System.Drawing.Point(177, 179);
            this.фамилияTextBox.Name = "фамилияTextBox";
            this.фамилияTextBox.Size = new System.Drawing.Size(292, 33);
            this.фамилияTextBox.TabIndex = 6;
            // 
            // имяLabel
            // 
            имяLabel.AutoSize = true;
            имяLabel.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            имяLabel.Location = new System.Drawing.Point(8, 218);
            имяLabel.Name = "имяLabel";
            имяLabel.Size = new System.Drawing.Size(56, 26);
            имяLabel.TabIndex = 7;
            имяLabel.Text = "Имя:";
            // 
            // имяTextBox
            // 
            this.имяTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.сведения_об_ЭкспертеBindingSource, "Имя", true));
            this.имяTextBox.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.имяTextBox.Location = new System.Drawing.Point(177, 218);
            this.имяTextBox.Name = "имяTextBox";
            this.имяTextBox.Size = new System.Drawing.Size(292, 33);
            this.имяTextBox.TabIndex = 8;
            // 
            // номер_рингаLabel
            // 
            номер_рингаLabel.AutoSize = true;
            номер_рингаLabel.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            номер_рингаLabel.Location = new System.Drawing.Point(8, 257);
            номер_рингаLabel.Name = "номер_рингаLabel";
            номер_рингаLabel.Size = new System.Drawing.Size(138, 26);
            номер_рингаLabel.TabIndex = 9;
            номер_рингаLabel.Text = "Номер ринга:";
            // 
            // номер_рингаTextBox
            // 
            this.номер_рингаTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.сведения_об_ЭкспертеBindingSource, "Номер ринга", true));
            this.номер_рингаTextBox.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.номер_рингаTextBox.Location = new System.Drawing.Point(177, 257);
            this.номер_рингаTextBox.Name = "номер_рингаTextBox";
            this.номер_рингаTextBox.Size = new System.Drawing.Size(292, 33);
            this.номер_рингаTextBox.TabIndex = 10;
            // 
            // название_клубаLabel
            // 
            название_клубаLabel.AutoSize = true;
            название_клубаLabel.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            название_клубаLabel.Location = new System.Drawing.Point(8, 296);
            название_клубаLabel.Name = "название_клубаLabel";
            название_клубаLabel.Size = new System.Drawing.Size(163, 26);
            название_клубаLabel.TabIndex = 11;
            название_клубаLabel.Text = "Название клуба:";
            // 
            // название_клубаTextBox
            // 
            this.название_клубаTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.сведения_об_ЭкспертеBindingSource, "Название клуба", true));
            this.название_клубаTextBox.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.название_клубаTextBox.Location = new System.Drawing.Point(177, 296);
            this.название_клубаTextBox.Name = "название_клубаTextBox";
            this.название_клубаTextBox.Size = new System.Drawing.Size(292, 33);
            this.название_клубаTextBox.TabIndex = 12;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Linen;
            this.ClientSize = new System.Drawing.Size(792, 669);
            this.Controls.Add(название_клубаLabel);
            this.Controls.Add(this.название_клубаTextBox);
            this.Controls.Add(номер_рингаLabel);
            this.Controls.Add(this.номер_рингаTextBox);
            this.Controls.Add(имяLabel);
            this.Controls.Add(this.имяTextBox);
            this.Controls.Add(фамилияLabel);
            this.Controls.Add(this.фамилияTextBox);
            this.Controls.Add(this.сведения_об_ЭкспертеBindingNavigator);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Эксперты";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.kONDRATEVADataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.сведения_об_ЭкспертеBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.сведения_об_ЭкспертеBindingNavigator)).EndInit();
            this.сведения_об_ЭкспертеBindingNavigator.ResumeLayout(false);
            this.сведения_об_ЭкспертеBindingNavigator.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private KONDRATEVADataSet kONDRATEVADataSet;
        private System.Windows.Forms.BindingSource сведения_об_ЭкспертеBindingSource;
        private KONDRATEVADataSetTableAdapters.Сведения_об_ЭкспертеTableAdapter сведения_об_ЭкспертеTableAdapter;
        private KONDRATEVADataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator сведения_об_ЭкспертеBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton сведения_об_ЭкспертеBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox фамилияTextBox;
        private System.Windows.Forms.TextBox имяTextBox;
        private System.Windows.Forms.TextBox номер_рингаTextBox;
        private System.Windows.Forms.TextBox название_клубаTextBox;
    }
}